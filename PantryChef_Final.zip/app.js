// =========================================================================
// 🚀 PANTRYCHEF AI - SERVERLESS LOGIC
// =========================================================================
console.log("🚀 app.js: Script started loading...");


// ⚠️ PASTE YOUR GEMINI API KEY HERE! ⚠️
const GEMINI_API_KEY = "AIzaSyDtm-LlWe_JvRyNN3n5vX-rUY7JoJoaNeg";

// =========================================================================

const uploadBtn = document.getElementById('upload-btn');
const fileInput = document.getElementById('image-upload');
const canvas = document.getElementById('image-canvas');
const ctx = canvas.getContext('2d');
const canvasContainer = document.getElementById('canvas-container');
const uploadZone = document.getElementById('upload-zone');
const scanLine = document.getElementById('scan-line');
const ingredientList = document.getElementById('ingredient-list');
const generateBtn = document.getElementById('generate-recipes-btn');

let currentImageElement = null;
let detectedIngredientsList = [];

// --- 1. Event Listeners ---
uploadBtn.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const base64Image = event.target.result;
        const img = new Image();
        img.onload = () => {
            // Setup Canvas
            uploadZone.style.display = 'none';
            canvasContainer.style.display = 'inline-block';
            
            // Resize canvas to max 800px width for performance
            const maxWidth = 800;
            const scale = Math.min(1, maxWidth / img.width);
            canvas.width = img.width * scale;
            canvas.height = img.height * scale;
            
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            currentImageElement = img;
            
            // Start Gemini Vision API Call
            callGeminiVision(base64Image, canvas.width, canvas.height);
        };
        img.src = base64Image;
    };
    reader.readAsDataURL(file);
});

// --- 2. Call Gemini API Directly ---
async function callGeminiVision(base64DataUrl, canvasWidth, canvasHeight) {
    scanLine.style.display = 'block';
    ingredientList.innerHTML = '<li class="empty-state" style="color: #10B981;">🚀 Analyzing image securely via Gemini Cloud...</li>';
    generateBtn.style.display = 'none';

    if (GEMINI_API_KEY === "YOUR_GEMINI_API_KEY_HERE") {
        scanLine.style.display = 'none';
        ingredientList.innerHTML = '<li class="empty-state" style="color: #E11D48;">⚠️ Error: You must paste your Gemini API Key at the top of app.js!</li>';
        return;
    }

    // Extract raw base64 string
    const base64Raw = base64DataUrl.split(',')[1];
    const mimeType = base64DataUrl.substring(5, base64DataUrl.indexOf(';'));

    const prompt = `
    Analyze this image of food or ingredients. 
    Identify all the main cooking ingredients visible.
    Return ONLY a valid JSON object in this exact format, with no markdown formatting:
    {
        "ingredients": ["apple", "potato", "etc"],
        "detections": [
            {
                "label": "apple",
                "box": [ymin, xmin, ymax, xmax] 
            }
        ]
    }
    The "box" coordinates must be scaled from 0 to 1000 representing the bounding box.
    `;

    const requestBody = {
        contents: [{
            parts: [
                { text: prompt },
                { inline_data: { mime_type: mimeType, data: base64Raw } }
            ]
        }],
        generationConfig: {
            temperature: 0.1
        }
    };

    try {
        // 1. Automatically discover the correct model for your API Key/Region!
        const modelsRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`);
        const modelsData = await modelsRes.json();
        
        let availableModels = [];
        if (modelsData.models) {
            availableModels = modelsData.models.map(m => m.name);
            console.log("Available Models on account:", availableModels);
        }
        
        // Preferred models in order of stability and rate-limit safety for free tier
        const priorities = [
            "models/gemini-flash-latest",    // Gemini 1.5 Flash alias (very high rate limits)
            "models/gemini-2.0-flash",       // Gemini 2.0 Flash
            "models/gemini-2.5-flash",       // Gemini 2.5 Flash
            "models/gemini-3.5-flash",       // Gemini 3.5 Flash (lower limits / high demand)
            "models/gemini-3-flash-preview"  // Gemini 3 Flash Preview
        ];
        
        // Build the sequence of models to try
        let modelsToTry = [];
        for (let p of priorities) {
            if (availableModels.includes(p)) {
                modelsToTry.push(p);
            }
        }
        
        // Add any other remaining flash/pro models that support generateContent
        if (modelsData.models) {
            modelsData.models.forEach(m => {
                if (m.supportedGenerationMethods && 
                    m.supportedGenerationMethods.includes('generateContent') && 
                    (m.name.includes('flash') || m.name.includes('pro')) &&
                    !modelsToTry.includes(m.name)) {
                    modelsToTry.push(m.name);
                }
            });
        }
        
        // Absolute fallback if list is empty
        if (modelsToTry.length === 0) {
            modelsToTry.push("models/gemini-flash-latest");
        }
        
        console.log("Planned model attempt path:", modelsToTry);
        
        let lastError = null;
        let success = false;
        let finalData = null;
        let chosenModel = "";
        
        for (let i = 0; i < modelsToTry.length; i++) {
            const currentModel = modelsToTry[i];
            console.log(`Attempting generation with model: ${currentModel}...`);
            ingredientList.innerHTML = `<li class="empty-state" style="color: #10B981;">🚀 Analyzing image using ${currentModel.split('/').pop()}...</li>`;
            
            try {
                const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${currentModel}:generateContent?key=${GEMINI_API_KEY}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
                
                const data = await response.json();
                
                if (data.error) {
                    throw new Error(data.error.message);
                }
                
                // If we got candidates and parts, it was successful!
                if (data.candidates && data.candidates[0] && data.candidates[0].content) {
                    finalData = data;
                    chosenModel = currentModel;
                    success = true;
                    break;
                } else {
                    throw new Error("Invalid response format from Gemini API");
                }
            } catch (err) {
                console.warn(`Model ${currentModel} failed:`, err.message);
                lastError = err;
                
                // If there are more models left, show a status update in the UI
                if (i < modelsToTry.length - 1) {
                    console.log(`Retrying with next model...`);
                }
            }
        }
        
        if (!success) {
            throw lastError || new Error("Failed to call any available Gemini model");
        }
        
        console.log(`Successful content generation using: ${chosenModel}`);
        scanLine.style.display = 'none';
        
        // Parse Gemini's JSON string
        let rawText = finalData.candidates[0].content.parts[0].text;
        // Strip markdown if Gemini ignores instructions
        rawText = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsedData = JSON.parse(rawText);

        if (Array.isArray(parsedData.ingredients)) {
            detectedIngredientsList = parsedData.ingredients;
        } else if (typeof parsedData.ingredients === 'string') {
            detectedIngredientsList = [parsedData.ingredients];
        } else {
            detectedIngredientsList = [];
        }
        
        // Draw boxes safely
        if (Array.isArray(parsedData.detections)) {
            drawBoxes(parsedData.detections, canvasWidth, canvasHeight);
        }

        // Update UI
        ingredientList.innerHTML = '';
        if (detectedIngredientsList.length === 0) {
            ingredientList.innerHTML = '<li class="empty-state">No ingredients found.</li>';
        } else {
            detectedIngredientsList.forEach(ing => {
                const li = document.createElement('li');
                li.innerHTML = `✅ ${ing}`;
                ingredientList.appendChild(li);
            });
            generateBtn.style.display = 'inline-block';
        }

    } catch (err) {
        console.error(err);
        scanLine.style.display = 'none';
        ingredientList.innerHTML = `<li class="empty-state" style="color: #E11D48;">⚠️ Detection failed: ${err.message}</li>`;
    }
}

// --- 3. Draw Bounding Boxes ---
function drawBoxes(detections, width, height) {
    ctx.lineWidth = 4;
    ctx.font = 'bold 20px Inter';

    if (!Array.isArray(detections)) return;

    detections.forEach(det => {
        if (!det || !det.box || !Array.isArray(det.box) || det.box.length < 4) {
            console.warn("Invalid or missing bounding box for detection:", det);
            return; // Skip this detection safely
        }
        
        const [ymin, xmin, ymax, xmax] = det.box;
        
        // Convert 0-1000 scale to canvas pixels
        const x1 = (xmin / 1000) * width;
        const y1 = (ymin / 1000) * height;
        const w = ((xmax - xmin) / 1000) * width;
        const h = ((ymax - ymin) / 1000) * height;

        // Draw Box
        ctx.strokeStyle = '#E11D48';
        ctx.strokeRect(x1, y1, w, h);

        // Draw Label Background
        ctx.fillStyle = '#E11D48';
        const labelText = (det.label || "food").toUpperCase();
        const textWidth = ctx.measureText(labelText).width;
        ctx.fillRect(x1, y1 - 30, textWidth + 20, 30);

        // Draw Label Text
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(labelText, x1 + 10, y1 - 8);
    });
}

// --- 4. Dynamic Recipe Generation ---
let currentRecipes = [];

const recipeModal = document.getElementById('recipe-modal');
const modalCloseBtn = document.getElementById('modal-close-btn');
const modalBody = document.getElementById('modal-body');

generateBtn.addEventListener('click', async () => {
    // Switch views
    document.getElementById('scan-view').style.display = 'none';
    document.getElementById('recipe-view').style.display = 'block';
    document.getElementById('nav-scan').classList.remove('active');
    document.getElementById('nav-recipes').classList.add('active');

    const grid = document.getElementById('recipes-grid');
    grid.innerHTML = `
        <div class="loader-container">
            <div class="spinner"></div>
            <p style="color: #10B981;">🍳 Generating 3 custom chef recipes using Gemini AI...</p>
        </div>
    `;

    try {
        const prompt = `
        Create exactly 3 distinct, creative, and delicious recipes that can be made using some or all of these ingredients: ${detectedIngredientsList.join(', ')}.
        You can assume standard pantry staples (like oil, salt, pepper, sugar, water, garlic, butter) are available.
        For each recipe, provide a title, prep/cook time, difficulty, short description, the specific scanned ingredients used, the pantry staples needed, and step-by-step instructions.
        Return ONLY a valid JSON array of 3 recipe objects, with no markdown formatting and no extra text, in this exact format:
        [
          {
            "title": "Recipe Name",
            "time": "30 mins",
            "difficulty": "Easy",
            "description": "Short mouth-watering description of the recipe.",
            "ingredientsUsed": ["ingredient1", "ingredient2"],
            "pantryStaples": ["oil", "salt"],
            "instructions": [
              "Step 1 details...",
              "Step 2 details...",
              "Step 3 details..."
            ]
          }
        ]
        `;

        const requestBody = {
            contents: [{
                parts: [{ text: prompt }]
            }],
            generationConfig: {
                temperature: 0.7
            }
        };

        // Discover correct model for this account
        const modelsRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`);
        const modelsData = await modelsRes.json();
        
        let availableModels = [];
        if (modelsData.models) {
            availableModels = modelsData.models.map(m => m.name);
        }
        
        const priorities = [
            "models/gemini-flash-latest",
            "models/gemini-2.0-flash",
            "models/gemini-2.5-flash",
            "models/gemini-3.5-flash",
            "models/gemini-3-flash-preview"
        ];
        
        let modelsToTry = [];
        for (let p of priorities) {
            if (availableModels.includes(p)) {
                modelsToTry.push(p);
            }
        }
        if (modelsToTry.length === 0) {
            modelsToTry.push("models/gemini-flash-latest");
        }

        let success = false;
        let finalData = null;
        let chosenModel = "";

        for (let i = 0; i < modelsToTry.length; i++) {
            const currentModel = modelsToTry[i];
            console.log(`Generating recipes with model: ${currentModel}...`);
            try {
                const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${currentModel}:generateContent?key=${GEMINI_API_KEY}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
                const data = await response.json();
                if (data.error) throw new Error(data.error.message);
                
                if (data.candidates && data.candidates[0] && data.candidates[0].content) {
                    finalData = data;
                    chosenModel = currentModel;
                    success = true;
                    break;
                }
            } catch (err) {
                console.warn(`Recipe generation with model ${currentModel} failed:`, err.message);
            }
        }

        if (!success) {
            throw new Error("Unable to contact Gemini API. Please check your network connection.");
        }

        let rawText = finalData.candidates[0].content.parts[0].text;
        rawText = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
        
        currentRecipes = JSON.parse(rawText);
        
        grid.innerHTML = '';
        
        if (!Array.isArray(currentRecipes) || currentRecipes.length === 0) {
            grid.innerHTML = '<p class="empty-state">No recipes could be generated. Try scanning different ingredients.</p>';
            return;
        }

        // Image keywords to pull nice Unsplash food photos
        const foodPhotos = [
            "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=500&q=80",
            "https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=500&q=80",
            "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=80"
        ];

        currentRecipes.forEach((recipe, idx) => {
            const cardImg = foodPhotos[idx % foodPhotos.length];
            
            const card = document.createElement('div');
            card.className = 'recipe-card';
            card.innerHTML = `
                <img src="${cardImg}" alt="${recipe.title}">
                <div class="recipe-info">
                    <h3>${recipe.title}</h3>
                    <p>⏱️ ${recipe.time} &nbsp;|&nbsp; 👨‍🍳 ${recipe.difficulty}</p>
                    <p style="margin-top: 5px; font-size: 0.85rem; color: #94A3B8;">${recipe.description || ''}</p>
                    <span class="badge" style="margin-top: 10px;">🍳 Cook Now</span>
                </div>
            `;
            
            card.addEventListener('click', () => openRecipeModal(idx));
            grid.appendChild(card);
        });

    } catch (err) {
        console.error("Recipe generation failed:", err);
        grid.innerHTML = `
            <div class="loader-container">
                <p style="color: #E11D48; font-weight: 600;">⚠️ Recipe Generation Failed: ${err.message}</p>
                <button class="btn primary glass-btn" style="margin-top: 15px;" onclick="location.reload()">Retry Scan</button>
            </div>
        `;
    }
});

// --- 5. Recipe Modal Details ---
function openRecipeModal(index) {
    const recipe = currentRecipes[index];
    if (!recipe) return;

    let ingredientsHTML = '';
    if (recipe.ingredientsUsed && recipe.ingredientsUsed.length > 0) {
        recipe.ingredientsUsed.forEach(ing => {
            ingredientsHTML += `<li>✅ ${ing}</li>`;
        });
    }
    
    let staplesHTML = '';
    if (recipe.pantryStaples && recipe.pantryStaples.length > 0) {
        recipe.pantryStaples.forEach(staple => {
            staplesHTML += `<li>🧂 ${staple}</li>`;
        });
    }

    let stepsHTML = '';
    if (recipe.instructions && recipe.instructions.length > 0) {
        recipe.instructions.forEach((step, idx) => {
            // Remove 'Step 1:', '1.' etc. if present to avoid double numbering
            const cleanStep = step.replace(/^(step\s*\d+\s*:\s*|\d+\s*[\.\:\-]\s*)/i, '').trim();
            stepsHTML += `<li data-step="${idx + 1}">${cleanStep}</li>`;
        });
    }

    modalBody.innerHTML = `
        <h2 class="modal-title">${recipe.title}</h2>
        <div class="modal-meta">
            <span>⏱️ <strong>Time:</strong> ${recipe.time}</span>
            <span>👨‍🍳 <strong>Difficulty:</strong> ${recipe.difficulty}</span>
        </div>
        
        <div class="modal-section" style="margin-top: 10px;">
            <p style="font-style: italic; color: #94A3B8; font-size: 1.05rem;">"${recipe.description || ''}"</p>
        </div>

        <div class="modal-section">
            <h4>Ingredients Used (From Scan)</h4>
            <ul class="ingredient-list" style="margin-top: 5px;">
                ${ingredientsHTML || '<li>None listed</li>'}
            </ul>
        </div>
        
        ${staplesHTML ? `
        <div class="modal-section">
            <h4>Pantry Staples Needed</h4>
            <ul class="ingredient-list" style="margin-top: 5px;">
                ${staplesHTML}
            </ul>
        </div>
        ` : ''}

        <div class="modal-section">
            <h4>Step-by-Step Instructions</h4>
            <ol class="instructions-list" style="margin-top: 10px;">
                ${stepsHTML || '<li>No steps listed.</li>'}
            </ol>
        </div>
    `;

    recipeModal.style.display = 'flex';
}

// Close Modal Event Listeners
modalCloseBtn.addEventListener('click', () => {
    recipeModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === recipeModal) {
        recipeModal.style.display = 'none';
    }
});

// Navigation handling
document.getElementById('nav-scan').addEventListener('click', function() {
    document.getElementById('recipe-view').style.display = 'none';
    document.getElementById('scan-view').style.display = 'block';
    this.classList.add('active');
    document.getElementById('nav-recipes').classList.remove('active');
});
document.getElementById('nav-recipes').addEventListener('click', function() {
    if (detectedIngredientsList.length > 0) {
        document.getElementById('scan-view').style.display = 'none';
        document.getElementById('recipe-view').style.display = 'block';
        this.classList.add('active');
        document.getElementById('nav-scan').classList.remove('active');
    }
});
